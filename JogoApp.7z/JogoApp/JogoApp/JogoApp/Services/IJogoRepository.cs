﻿using JogoApp.Models;
using System.Collections.Generic;

namespace JogoApp.Services
{
    public interface IJogoRepository
    {
        List<Jogo> GetAllJogosData();

        Jogo GetJogoData(int JogoID);

        void DeleteAllJogos();

        void DeleteJogo(int JogoID);

        void InsertJogo(Jogo Jogo);

        void UpdateJogo(Jogo Jogo);
    }
}
