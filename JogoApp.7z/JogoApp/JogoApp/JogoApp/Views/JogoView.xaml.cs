﻿using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace JogoApp.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class JogoView : ContentView
	{
		public JogoView ()
		{
			InitializeComponent ();
		}
	}
}