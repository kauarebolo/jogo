﻿using PCLExt.FileStorage;
using PCLExt.FileStorage.Folders;
using JogoApp.Models;
using SQLite;
using System.Collections.Generic;
using System.Linq;

namespace JogoApp.Helpers
{
    public class DatabaseHelper
    {
        static SQLiteConnection sqliteconnection;
        public const string DbFileName = "JogosDB.db";

        public DatabaseHelper()
        {
            var pasta = new LocalRootFolder();
            var arquivo = pasta.CreateFile(DbFileName, CreationCollisionOption.OpenIfExists);
            sqliteconnection = new SQLiteConnection(arquivo.Path);
            sqliteconnection.CreateTable<Jogo>();
        }

        public List<Jogo> GetAllJogosData()
        {
            return (from data in sqliteconnection.Table<Jogo>()
                    select data).ToList();
        }

        public Jogo GetJogoData(int id)
        {
            return sqliteconnection.Table<Jogo>().FirstOrDefault(t => t.Id == id);
        }

        public void DeleteAllJogos()
        {
            sqliteconnection.DeleteAll<Jogo>();
        }

        public void DeleteJogo(int id)
        {
            sqliteconnection.Delete<Jogo>(id);
        }

        public void InsertJogo(Jogo Jogo)
        {
            sqliteconnection.Insert(Jogo);
        }

        public void UpdateJogo(Jogo Jogo)
        {
            sqliteconnection.Update(Jogo);
        }
    }
}
